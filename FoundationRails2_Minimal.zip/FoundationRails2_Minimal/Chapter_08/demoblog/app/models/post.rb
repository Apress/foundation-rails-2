class Post < ActiveRecord::Base
  before_save :generate_permalink 
  
  def generate_permalink
    self.permalink = headline.gsub(/[^a-z1-9]+/i, '_')
  end
end
