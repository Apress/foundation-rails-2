class Member < ActiveRecord::Base
  
  validates_acceptance_of :accepted 
  validates_confirmation_of :password 
end

 