class CreateMembers < ActiveRecord::Migration
  def self.up
    create_table :members do |t|
      t.string :login, :name, :password, :address, :city, :state, :zip, :phone
      t.integer :age, :weight
      t.timestamps
    end
  end

  def self.down
    drop_table :members
  end
end
