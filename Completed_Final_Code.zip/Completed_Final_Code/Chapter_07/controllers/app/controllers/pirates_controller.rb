class PiratesController < ApplicationController
  
  before_filter :lookup_pirate, :except => [:index, :new, :create]

  def index
    @pirates = Pirate.find :all
  end

  def show
  end
  
  def new
    @pirate = Pirate.new
  end
  
  def create
    @pirate = Pirate.new(params[:pirate])
    if @pirate.save
      redirect_to :action => 'show', :id => @pirate
    else
      render :action => 'new'
    end
  end
  
  def edit
  end
  
  def update
    if @pirate.update_attributes(params[:pirate])
      redirect_to :action => 'show', :id => @pirate
    else
      render :action => 'new'
    end
  end
  
  def destroy
    @pirate.destroy
    redirect_to :action => 'index'
  end
  
protected

  def lookup_pirate
    @pirate = Pirate.find(params[:id])
  end
  
end
