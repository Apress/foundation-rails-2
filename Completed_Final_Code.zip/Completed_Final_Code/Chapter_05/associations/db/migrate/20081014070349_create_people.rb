class CreatePeople < ActiveRecord::Migration
  def self.up
    create_table :people do |t|
      t.string :name
      t.string :address
      t.string :dress_size
      t.string :tux_size
      t.boolean :wedding_rsvp
      t.boolean :rehearsal_rsvp
      t.string :type

      t.timestamps
    end
  end

  def self.down
    drop_table :people
  end
end
