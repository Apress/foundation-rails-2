class Member < ActiveRecord::Base 
  validates_presence_of :login, :name 
  # validates_length_of :zip, :is => 5 
  validates_format_of :zip, :with => /^\d{5}/ 
  validates_numericality_of :age, :weight, :allow_nil => true 
  validates_uniqueness_of :login, :allow_nil => true 
  validates_acceptance_of :accepted, :accept => true 
  validates_confirmation_of :password 

  private 
  
  def validate 
    if weight.nil? && age.nil? 
      errors.add_to_base 'Must provide either your weight or your age' 
    end 
  end 
end 
