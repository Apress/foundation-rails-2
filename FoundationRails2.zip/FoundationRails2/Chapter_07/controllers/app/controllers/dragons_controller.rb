class DragonsController < ApplicationController
  def index
    
  end
end
