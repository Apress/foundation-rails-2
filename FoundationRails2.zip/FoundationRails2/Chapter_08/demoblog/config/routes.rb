ActionController::Routing::Routes.draw do |map|
  map.connect 'stories.php/storyID/:id', :controller => 'posts', :action => 'show'
  map.connect 'stories.php', :controller => 'posts', :action => 'show'
  
  map.connect 'blog/Reasons_I_Rock', :controller => 'posts', :action => 'show', :id => 101  
  map.connect 'blog', :controller => 'posts'
  map.connect 'blog/:id', :controller => 'posts', :action => 'show'

  map.connect "blog/:year/:month/:day", 
    :controller => "posts", 
    :action => "show_date", 
    :requirements => { :year => /(19|20)\d\d/, 
      :month => /[01]?\d/, 
      :day => /[0-3]?\d/}, 
      :day => nil, 
      :month => nil 

  map.resources :posts, :collection => {:showall => :any}
  map.root :controller => 'posts'
  map.connect ':controller/:action/:id'
  map.connect ':controller/:action/:id.:format'  
end
