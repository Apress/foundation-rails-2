require 'test_helper'

class BanksControllerTest < ActionController::TestCase
  def test_should_get_index
    get :index
    assert_response :success
    assert_not_nil assigns(:banks)
  end

  def test_should_get_new
    get :new
    assert_response :success
  end

  def test_should_create_bank
    assert_difference('Bank.count') do
      post :create, :bank => { }
    end

    assert_redirected_to bank_path(assigns(:bank))
  end

  def test_should_show_bank
    get :show, :id => banks(:one).id
    assert_response :success
  end

  def test_should_get_edit
    get :edit, :id => banks(:one).id
    assert_response :success
  end

  def test_should_update_bank
    put :update, :id => banks(:one).id, :bank => { }
    assert_redirected_to bank_path(assigns(:bank))
  end

  def test_should_destroy_bank
    assert_difference('Bank.count', -1) do
      delete :destroy, :id => banks(:one).id
    end

    assert_redirected_to banks_path
  end
end
