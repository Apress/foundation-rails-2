class Guest < Person 
end 