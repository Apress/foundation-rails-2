class Groom < Person 
  validates_presence_of :tux_size 
end 
