ActionController::Routing::Routes.draw do |map|
  map.resources :posts
  map.root :posts
end
