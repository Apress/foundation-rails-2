require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe PageController do

  it "should use PageController" do
    controller.should be_an_instance_of(PageController)
  end

  describe "GET 'index'" do
    it "should be successful" do
      get 'index'
      response.should be_success
      response.should render_template(:index)
    end
    
    it "should be the root page" do
      route_for(:controller => "page", :action => "index").should == "/"
    end
  end
end
