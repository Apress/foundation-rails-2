class PostsController < ApplicationController

  def index
    @posts = Post.find(:all)
  end

  def show
    id = params[:id] || params[:storyID]
    @post = Post.find(id)
  end
  
  def new
    @post = Post.new
  end

  def edit
    @post = Post.find(params[:id])
  end

  def create
    @post = Post.new(params[:post])
    if @post.save
      flash[:notice] = 'Post was successfully created.'
      redirect_to :action => "show", :id => @post
    else
      render :action => "new" 
    end
  end

  def update
    @post = Post.find(params[:id])
    if @post.update_attributes(params[:post])
      flash[:notice] = 'Post was successfully updated.'
      redirect_to :action => "show", :id => @post
    else
      render :action => "edit"
    end
  end

  def destroy
    @post = Post.find(params[:id])
    @post.destroy
    redirect_to :action => "index"
  end
  
  def show_date
    date = params.values_at(:year, :month, :day).join('-') 
    if @post = Post.find(:first, :conditions => ['created_at = ?', date] )
      render :action => "show"
    else
      redirect_to :action => 'index'
    end
  end
end
