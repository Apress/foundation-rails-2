class Bank < ActiveRecord::Base
end
