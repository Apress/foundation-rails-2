ActionController::Routing::Routes.draw do |map|
  map.resources :banks

  map.resources :plugins, :has_many => :ratings
  # map.resources :plugins, :collection => {:recent => :get}, :has_many => :ratings
  map.resources :categories
  map.root :controller => 'plugins'
end
