require File.expand_path(File.dirname(__FILE__) + '/../spec_helper')

describe ToysController do

  describe "GET 'new'" do
    before(:each) do
      @toy = mock_model(Toy, :build => @toy)   
      @user = mock_model(User, :toys => @toy )
      controller.stub!( :current_user ).and_return(@user)     
    end

    describe "with request for LOST" do
      it "should render the lost template" do
        get 'new', {:type => "LOST"}
        response.should render_template("lost")
      end
    end
    
    describe "with request for FOUND" do
      it "should render the found template" do
        get 'new', {:type => "FOUND"}
        response.should render_template("found")
      end
    end
  end
  
  describe "POST to Create" do
    before(:each) do
      @toy = mock_model(Toy, :build => @toy)   
      @user = mock_model(User, :toys => @toy )
      controller.stub!( :current_user ).and_return(@user)     
    end
    
    it "should description" do
      
    end
  end
  
  
  
  # def create
  #   @toy = current_user.toys.build(params[:toy])
  #   if @toy.save
  #     redirect_to(@toy)
  #   else
  #     case params[:toy][:status]
  #       when "LOST" then render :file => 'toys/lost', :use_full_path => true, :layout => true
  #       when "FOUND" then render :file => 'toys/found', :use_full_path => true, :layout => true
  #     end
  #   end
  # end
  
end
