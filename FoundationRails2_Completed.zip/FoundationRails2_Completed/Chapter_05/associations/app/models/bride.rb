class Bride < Person 
  validates_presence_of :dress_size 
end