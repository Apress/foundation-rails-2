module PiratesHelper
end
