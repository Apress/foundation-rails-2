class Pirate < ActiveRecord::Base
  validates_presence_of :name, :ship
end